void main(){ 
	int *ptr,*t;
	int p;
	ptr=&p;
	*ptr = 5;
	if(*ptr > 4){
		*t=4;
	}
	
}