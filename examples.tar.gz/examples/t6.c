int *g;

int *f(int x, int *y);

void main(){
	int x ,**y,**z;
	float *rt;
	*y=*z;
	*rt = 9.8;
	g = f(3,g);
}

int* f(int a, int *c)
{
	int **b;
	return *b;
}
