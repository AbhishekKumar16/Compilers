int *func1(int a, int b)
{
    int *c;
    return c;   
}
