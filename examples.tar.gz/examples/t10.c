int *g3, l3, *g;


int *func2(int x1, int y1);
float *var1, var2;

void func1(int a, int b)
{
    int **h;
    if( *g3 == 52)
    {
        while(  **h != 0)
        {
            **h = *g3 + 1;
            
        }
    }
    return ;
}

void main()
{
    int *a,*b, *h;
    g3 = func2(3, *a);
    if( *g3 == 52)
    {
        while(  *h != 0)
        {
            *g3 = *g3 + 1;
        }
    }
    
}

int *func2(int a, int b)
{
    int *h;
    if( *g3 == 52)
    {
        while(  *h != 0)
        {
            *g3 = *g3 + 1;
        }
    }
    
    return h;
}

