void main(){ 
	int *ptr,*t;
	int p;
	ptr=&p;
	*ptr = 5;
	while(!(*ptr > 4)){
		*t=4;
	}
	
}