
void main()
{ 
	int *ptr;
	int a;
	ptr=&a;
	*ptr = 2;
}
