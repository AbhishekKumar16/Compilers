int *d;

int* f(int a, int b)
{
	int *c,m;
        c = &m;
	return c;
}


void main(){
	
	int x ,y;
	d = f(3,4);

}
