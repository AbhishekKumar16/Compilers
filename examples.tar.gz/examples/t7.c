int *f(float a, int b);

void main(){
	int *y;
	float *x;
	int *ans;
	ans = f(*x,*y);
}

int *f(float x, int y){
	int z;
	int *t;
	return t;
}
