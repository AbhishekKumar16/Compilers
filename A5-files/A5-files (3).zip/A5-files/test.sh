./Parser $1
./read_sym $1 